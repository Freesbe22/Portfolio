<script setup>

</script>

<template>
    <div id="HomeInfraSlide"
        class="h-full w-full overflow-hidden z-20 embla__slide text-center flex items-center justify-center flex-col text-white tracking-wide">
        <h1 class="text-5xl uppercase font-bold">
            Adminstrateur Système
        </h1>
        <h2 class="text-lg">
            Gestion, maintenance, sécurisation d'une infrastructure informatique
        </h2>
    </div>
</template>
