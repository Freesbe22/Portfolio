<script setup>

</script>

<template>
    <div id="HomeDevSlide" class="h-full w-full overflow-hidden z-20 embla__slide text-center flex items-center justify-center flex-col text-white tracking-wide">
            <h2 class="text-lg">
                MIDEY Baptiste
            </h2>
                <h1 class="text-5xl uppercase font-bold">
                    Développeur informatique
                </h1>
                <h1 class="text-5xl uppercase font-bold">
                    .NET (C#, Blazor, ...)
                </h1>
        </div>
</template>
